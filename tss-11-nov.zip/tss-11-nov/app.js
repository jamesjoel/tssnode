// -----Creating Express Object
var express=require('express');
// initilize application form Express Object
var app=express();

// Create Body Parser object for getting form data
var bodyParser=require('body-parser');


// setting some variable for application
app.set('views', __dirname+'/views');
app.set('view engine', 'ejs');


//Using urlencoded for "GET" data from bodyParser Object
app.use(bodyParser.urlencoded());
//use 'public' folder for every client slide externale "url"
app.use(express.static(__dirname+'/public'));


// read "/" path and send index.ejs file with some data
app.get('/', function(req, res){
	var data={ name : "Rohit", age : 25 };
	res.render('index', data);
})


// read '/' path with "POST" data and console it
app.post('/', function(req, res){
	console.log(req.body);
})


// Start the server with 3000 port
app.listen(3000, function(){
	console.log('Server Running');
})


